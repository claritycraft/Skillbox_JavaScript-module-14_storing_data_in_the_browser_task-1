// Функция для добавления фильма в localStorage
function addFlmLocationStorage(film) {
  const films = JSON.parse(localStorage.getItem("films")) || [];
  films.push(film);
  localStorage.setItem("films", JSON.stringify(films));
  renderTable();
  toggleFormButtons(true);
}

// Функция для рендеринга таблицы с фильмами
function renderTable() {
  const films = JSON.parse(localStorage.getItem("films")) || [];
  const filmTableBody = document.querySelector("#film-tbody");
  filmTableBody.innerHTML = "";

  films.forEach((film, index) => {
    const row = document.createElement("tr");
    row.innerHTML = `
            <td>${film.title}</td>
            <td>${film.genre}</td>
            <td>${film.releaseYear}</td>
            <td>${film.isWatched ? "Да" : "Нет"}</td>
            <td>
                <button onclick="editFilm(${index})">Редактировать</button>
                <button onclick="deleteFilm(${index})">Удалить</button>
            </td>
        `;
    filmTableBody.appendChild(row);
  });
}

// Функция для удаления фильма
function deleteFilm(index) {
  const films = JSON.parse(localStorage.getItem("films"));
  films.splice(index, 1);
  localStorage.setItem("films", JSON.stringify(films));
  renderTable();
}

// Функция для редактирования фильма
function editFilm(index) {
  const films = JSON.parse(localStorage.getItem("films"));
  const film = films[index];

  // Заполняем форму данными фильма
  document.querySelector("#title").value = film.title;
  document.querySelector("#genre").value = film.genre;
  document.querySelector("#releaseYear").value = film.releaseYear;
  document.querySelector("#isWatched").checked = film.isWatched;

  // Обновляем кнопку отправки формы
  const submitButton = document.querySelector('button[type="submit"]');
  submitButton.innerHTML = "Обновить";

  // Добавляем возможность обновления фильма
  submitButton.onclick = function () {
    updateFilm(index);
  };

  // Показываем кнопку "Отменить редактирование"
  toggleFormButtons(false);
}

// Функция для обновления фильма
function updateFilm(index) {
  const films = JSON.parse(localStorage.getItem("films"));

  films[index] = {
    title: document.querySelector("#title").value,
    genre: document.querySelector("#genre").value,
    releaseYear: document.querySelector("#releaseYear").value,
    isWatched: document.querySelector("#isWatched").checked,
  };

  localStorage.setItem("films", JSON.stringify(films));
  renderTable();

  // Сбрасываем форму и кнопку
  document.querySelector("#film-form").reset();
  const submitButton = document.querySelector('button[type="submit"]');
  submitButton.innerHTML = "Добавить фильм";

  // Показываем кнопку "Добавить фильм"
  toggleFormButtons(true);
}

// Функция для сортировки фильмов
function sortFilms() {
  const sortCriteria = document.querySelector("#sort").value;
  const films = JSON.parse(localStorage.getItem("films")) || [];

  films.sort((a, b) => {
    if (a[sortCriteria] < b[sortCriteria]) return -1;
    if (a[sortCriteria] > b[sortCriteria]) return 1;
    return 0;
  });

  localStorage.setItem("films", JSON.stringify(films));
  renderTable();
}

// Функция для валидации формы
function validateForm() {
  const title = document.querySelector("#title").value;
  const genre = document.querySelector("#genre").value;
  const releaseYear = document.querySelector("#releaseYear").value;

  if (!title || !genre || !releaseYear) {
    alert("Все поля должны быть заполнены!");
    return false;
  }

  return true;
}

// Обработчик отправки формы
function handleFormSubmit(e) {
  e.preventDefault();

  if (!validateForm()) return;

  const title = document.querySelector("#title").value;
  const genre = document.querySelector("#genre").value;
  const releaseYear = document.querySelector("#releaseYear").value;
  const isWatched = document.querySelector("#isWatched").checked;

  const film = { title, genre, releaseYear, isWatched };
  addFlmLocationStorage(film);

  // Сбрасываем форму после добавления фильма
  document.querySelector("#film-form").reset();
}

// Функция для отображения/скрытия кнопок "Обновить" и "Отменить редактирование"
function toggleFormButtons(showAddButton) {
  const addButton = document.querySelector('button[type="submit"]');
  const cancelButton = document.querySelector("#cancel-edit");

  if (showAddButton) {
    addButton.innerHTML = "Добавить фильм";
    if (cancelButton) cancelButton.style.display = "none";
  } else {
    addButton.innerHTML = "Обновить";
    if (!cancelButton) {
      const cancelBtn = document.createElement("button");
      cancelBtn.id = "cancel-edit";
      cancelBtn.innerHTML = "Отменить редактирование";
      cancelBtn.onclick = cancelEdit;
      document.querySelector("#film-form").appendChild(cancelBtn);
    }
  }
}

// Функция для отмены редактирования
function cancelEdit() {
  document.querySelector("#film-form").reset();
  toggleFormButtons(true);
}

// Подключаем обработчик к форме
document
  .querySelector("#film-form")
  .addEventListener("submit", handleFormSubmit);

// Инициализация таблицы при загрузке страницы
document.addEventListener("DOMContentLoaded", renderTable);
