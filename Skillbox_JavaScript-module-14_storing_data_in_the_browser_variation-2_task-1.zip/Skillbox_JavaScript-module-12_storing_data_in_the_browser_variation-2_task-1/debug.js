function handleFormSubmit(e) {
  console.log("1 Работает функция Обработчик отправки формы handleFormSubmit");
  e.preventDefault();

  const title = document.querySelector("#title").value.trim();
  const genre = document.querySelector("#genre").value.trim();
  const releaseYear = String(
    document.querySelector("#releaseYear").value.trim()
  );

  const isWatched = document.querySelector("#isWatched").checked;

  const film = { title, genre, releaseYear, isWatched };
  saveFilm(film);
}

function addFilmLocalStorage(film) {
  console.log("2 Работает функция addFilmLocalStorage");
  const films = JSON.parse(localStorage.getItem("films")) || [];

  films.push(film);

  localStorage.setItem("films", JSON.stringify(films));
  renderTable();
}

function renderTable() {
  console.log(
    "3 Работает функция отображения масива из локал сторейдж renderTable"
  );
  const films = JSON.parse(localStorage.getItem("films")) || [];

  const criteria = getSortCriteria();
  const filteredFilms = filterFilms(films, criteria);

  const filmTableBody = document.querySelector("#film-tbody");

  filmTableBody.innerHTML = "";

  filteredFilms.forEach((film, index) => {
    const row = document.createElement("tr");

    row.innerHTML = `

            <td>${film.title}</td>
            <td>${film.genre}</td>
            <td>${film.releaseYear}</td>
            <td>${film.isWatched ? "Да" : "Нет"}</td>
            <td>
                <button onclick="editFilm(${index})">Редактировать</button>

                <button onclick="deleteFilm(${index})">Удалить</button>
            </td>
        `;

    filmTableBody.appendChild(row);
  });
}

function deleteFilm(index) {
  console.log("4 Работает функция удаления фильма deleteFilm");
  const films = JSON.parse(localStorage.getItem("films")) || [];

  films.splice(index, 1);

  localStorage.setItem("films", JSON.stringify(films));
  renderTable();
}

let editIndex = null;

function editFilm(index) {
  console.log(
    "5 Работает функция заполнение формы данными выбранного фильма editFilm"
  );
  const films = JSON.parse(localStorage.getItem("films")) || [];

  editIndex = index;

  const film = films[index];
  document.getElementById("title").value = film.title;
  document.getElementById("genre").value = film.genre;
  document.getElementById("releaseYear").value = film.releaseYear;
  document.getElementById("isWatched").checked = film.isWatched;
}

function saveFilm(film) {
  console.log(
    "7 Работает функция решающая добавить новый фильм или обновить существующий  saveFilm"
  );
  if (editIndex !== null) {
    updateFilm(editIndex, film);
  } else {
    addFilmLocalStorage(film);
  }

  document.querySelector("#film-form").reset();
  editIndex = null;
}

function updateFilm(index, updatedFilm) {
  console.log("6 Работает функция редактирования фильма  updateFilm");
  const films = JSON.parse(localStorage.getItem("films")) || [];
  films[index] = updatedFilm;
  localStorage.setItem("films", JSON.stringify(films));
  renderTable();
}

function getSortCriteria() {
  console.log(
    "8 Работает функция сбора выбранных фильтров пользователем getSortCriteria"
  );
  const movie = document.querySelector("#movie").value;
  const genre = document.querySelector("#genre-movie").value;
  const year = document.querySelector("#year").value;
  return { movie, genre, year };
}

document.querySelector("#movie").addEventListener("change", renderTable);
document.querySelector("#genre-movie").addEventListener("change", renderTable);
document.querySelector("#year").addEventListener("change", renderTable);

function filterFilms(films, { movie, genre, year }) {
  console.log("9 Работает функция для фильтрации фильмаfilterFilms");
  let filtered = [...films];

  if (movie && movie !== "no-name") {
    filtered = filtered.filter((f) => f.title === movie);
  }
  if (genre && genre !== "no-genre") {
    filtered = filtered.filter((f) => f.genre === genre);
  }
  if (year && year !== "no-year") {
    filtered = filtered.filter((f) => String(f.releaseYear) === year);
  }

  return filtered;
}

document.querySelector("#reset-filter").addEventListener("click", () => {
  console.log("10 Работает ОБРАБОТЧИК reset-filter");
  document.querySelector("#movie").value = "no-name";
  document.querySelector("#genre-movie").value = "no-genre";
  document.querySelector("#year").value = "no-year";
  renderTable();
});

document
  .querySelector("#film-form")
  .addEventListener("submit", handleFormSubmit);

renderTable();
